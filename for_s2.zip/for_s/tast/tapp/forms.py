from .models import Upload_Pdf
from django import forms

class PhotoForm(forms.ModelForm):
    class Meta:
        model = Upload_Pdf
        fields = ('file', )