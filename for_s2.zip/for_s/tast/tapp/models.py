from django.db import models

# Create your models here.
def validate_file_extension1(value):
    import os
    from django.core.exceptions import ValidationError
    ext = os.path.splitext(value.name)[-1]  # [0] returns path+filename
    valid_extensions = ['.pdf',]
    if not ext.lower() in valid_extensions:
        raise ValidationError('Unsupported file extension.')

class Upload_Pdf(models.Model):
    title = models.CharField(max_length=255, blank=True)
    file = models.FileField(upload_to='files/',validators=[validate_file_extension1])
    uploaded_at = models.DateTimeField(auto_now_add=True)